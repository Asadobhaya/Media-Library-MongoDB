const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);

const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

dotenv.config();
connectDB();

const app = express();
app.use(express.json());
app.use(express.static('public'));

// Routes
app.use('/api/auth',      require('./routes/auth'));
app.use('/api/songs',     require('./routes/songs'));
app.use('/api/playlists', require('./routes/playlists'));
app.use('/api/comments',  require('./routes/comments'));
app.use('/api/ratings',   require('./routes/ratings'));
app.use('/api/stats',     require('./routes/stats'));

app.get('/', (req, res) => res.send('Media Library API Running'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));