const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);

require('dotenv').config();
const mongoose = require('mongoose');
const Song = require('./models/Song');

async function setup() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected...');

  const db = mongoose.connection.db;

  // ─── INDEXES ─────────────────────────────────────────
  console.log('Creating indexes...');
  await db.collection('songs').createIndex({ title: 'text', artist: 'text' });
  await db.collection('songs').createIndex({ 'genre.name': 1 });
  await db.collection('songs').createIndex({ 'stats.totalPlays': -1 });
  await db.collection('songs').createIndex({ 'stats.avgRating': -1 });
  await db.collection('ratings').createIndex({ songId: 1, userId: 1 }, { unique: true });
  await db.collection('playhistories').createIndex({ songId: 1 });
  await db.collection('playhistories').createIndex({ userId: 1, playedOn: -1 });
  console.log('✅ Indexes created');

  // ─── VIEWS ───────────────────────────────────────────
  console.log('Creating views...');

  // Drop if exist
  const collections = await db.listCollections().toArray();
  const names = collections.map(c => c.name);

  if (names.includes('topRatedSongsView')) await db.dropCollection('topRatedSongsView');
  if (names.includes('trendingSongsView'))  await db.dropCollection('trendingSongsView');

  // Top Rated Songs View
  await db.createCollection('topRatedSongsView', {
    viewOn: 'songs',
    pipeline: [
      { $match: { 'stats.totalRatings': { $gt: 0 } } },
      { $sort:  { 'stats.avgRating': -1 } },
      { $limit: 10 },
      { $project: { title: 1, artist: 1, 'genre.name': 1, 'stats.avgRating': 1, 'stats.totalRatings': 1 } }
    ]
  });

  // Trending Songs View (most played)
  await db.createCollection('trendingSongsView', {
    viewOn: 'songs',
    pipeline: [
      { $match: { 'stats.totalPlays': { $gt: 0 } } },
      { $sort:  { 'stats.totalPlays': -1 } },
      { $limit: 10 },
      { $project: { title: 1, artist: 1, 'genre.name': 1, 'stats.totalPlays': 1 } }
    ]
  });

  console.log('✅ Views created: topRatedSongsView, trendingSongsView');

  // ─── SAMPLE DATA ─────────────────────────────────────
  console.log('Adding sample songs...');
  const existing = await Song.countDocuments();
  if (existing >= 10) {
    console.log('✅ Sample data already exists, skipping.');
  } else {
   await Song.insertMany([
  // 🌍 International
  { title: 'Blinding Lights',    artist: 'The Weeknd',     youtubeId: 'fHI8X4OXluQ', album: { name: 'After Hours', releaseYear: 2020 },             genre: { name: 'Pop' } },
  { title: 'Shape of You',       artist: 'Ed Sheeran',     youtubeId: 'JGwWNGJdvx8', album: { name: 'Divide', releaseYear: 2017 },                   genre: { name: 'Pop' } },
  { title: 'Hotel California',   artist: 'Eagles',         youtubeId: 'BciS5krYL80', album: { name: 'Hotel California', releaseYear: 1977 },          genre: { name: 'Rock' } },
  { title: 'Strobe',             artist: 'deadmau5',       youtubeId: 'tKi9Z-f6qX4', album: { name: 'For Lack of a Better Name', releaseYear: 2009 }, genre: { name: 'Electronic' } },

  // 🎵 Pakistani Songs
  { title: 'Afreen Afreen',      artist: 'Rahat Fateh Ali Khan & Momina Mustehsan', youtubeId: 'tqMcA3QPPBY', album: { name: 'Coke Studio Season 9', releaseYear: 2016 },  genre: { name: 'Pakistani' } },
  { title: 'Pasoori',            artist: 'Ali Sethi & Shae Gill',                   youtubeId: 'Z-DSFKMbJgU', album: { name: 'Coke Studio Season 14', releaseYear: 2022 }, genre: { name: 'Pakistani' } },
  { title: 'Tajdar-e-Haram',     artist: 'Atif Aslam',                              youtubeId: 'I0-oDpAOGXA', album: { name: 'Coke Studio Season 8', releaseYear: 2015 },  genre: { name: 'Pakistani' } },
  { title: 'Dil Dil Pakistan',   artist: 'Vital Signs',                             youtubeId: 'nNpGSNjRNkA', album: { name: 'Vital Signs 1', releaseYear: 1987 },          genre: { name: 'Pakistani' } },
  { title: 'Kana Yaari',         artist: 'Eva B & Talha Anjum',                     youtubeId: 'gMZ-iHMEZQw', album: { name: 'Coke Studio Season 14', releaseYear: 2022 }, genre: { name: 'Pakistani' } },
  { title: 'Woh Lamhe',          artist: 'Atif Aslam',                              youtubeId: 'GFCFJBQFkAA', album: { name: 'Doorie', releaseYear: 2006 },                 genre: { name: 'Pakistani' } },
  { title: 'Mustt Mustt',        artist: 'Nusrat Fateh Ali Khan',                   youtubeId: 'TBMfBBaJR4s', album: { name: 'Mustt Mustt', releaseYear: 1990 },            genre: { name: 'Pakistani' } },
  { title: 'Tera Woh Pyar',      artist: 'Momina Mustehsan & Asim Azhar',           youtubeId: 'WxSABMSBPkE', album: { name: 'Coke Studio Season 9', releaseYear: 2016 },  genre: { name: 'Pakistani' } },

  // ☪️ Naats
  { title: 'Taiba Taiba',                artist: 'Hafiz Tahir Qadri',    youtubeId: 'aSDsxBCAMV8', album: { name: 'Naats Collection', releaseYear: 2010 }, genre: { name: 'Naat' } },
  { title: 'Hussain Jaane Jigar',        artist: 'Syed Fasihuddin Soharwardi', youtubeId: 'NqBRgKQPzQ8', album: { name: 'Islamic Collection', releaseYear: 2008 }, genre: { name: 'Naat' } },
  { title: 'Allah Hu Allah Hu',          artist: 'Qari Waheed Zafar Qasmi', youtubeId: 'XBu0lDKMxn4', album: { name: 'Hamd Collection', releaseYear: 2005 },   genre: { name: 'Naat' } },
  { title: 'Salle Ala',                  artist: 'Hafiz Tahir Qadri',    youtubeId: '9vST-RBPPFY', album: { name: 'Naats Collection', releaseYear: 2012 }, genre: { name: 'Naat' } },
  { title: 'Meri Umeed Mera Sahara',     artist: 'Hafiz Tahir Qadri',    youtubeId: 'wYUQHFkiREo', album: { name: 'Naats Collection', releaseYear: 2011 }, genre: { name: 'Naat' } },
  { title: 'Ya Nabi Salam Alayka',       artist: 'Syed Fasihuddin Soharwardi', youtubeId: 'pqkBBFVFiac', album: { name: 'Durood Collection', releaseYear: 2009 }, genre: { name: 'Naat' } },
]);
    console.log('✅ Sample songs added');
  }

  console.log('\n🎉 Setup complete!');
  process.exit(0);
}

setup().catch(err => {
  console.error('Setup failed:', err.message);
  process.exit(1);
});