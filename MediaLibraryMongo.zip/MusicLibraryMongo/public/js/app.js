const API = '';
let token = localStorage.getItem('token') || '';
let role  = localStorage.getItem('role')  || '';
let currentSongId = null;
window.currentSongId = null;
window.selectedRating = 0;
let selectedRating = 0;
let editingSongId  = null;

// ─── GENRE CLASS ─────────────────────────────────────
function genreClass(genre) {
  const map = {
    'Pop':'tag-pop','Rock':'tag-rock','Jazz':'tag-jazz',
    'Hip-Hop':'tag-hip-hop','Classical':'tag-classical',
    'Electronic':'tag-electronic','Pakistani':'tag-pakistani','Naat':'tag-naat'
  };
  return map[genre] || 'tag-pop';
}

// ─── PAGES ───────────────────────────────────────────
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(name + 'Page').classList.add('active');

  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const navEl = document.getElementById('nav' + name.charAt(0).toUpperCase() + name.slice(1));
  if (navEl) navEl.classList.add('active');

  const gradients = {
    home:      'linear-gradient(180deg, #1a3a2a 0%, #121212 40%)',
    playlists: 'linear-gradient(180deg, #1a1a3a 0%, #121212 40%)',
    stats:     'linear-gradient(180deg, #2a1a3a 0%, #121212 40%)',
    admin:     'linear-gradient(180deg, #3a1a1a 0%, #121212 40%)',
  };
  const mc = document.getElementById('mainContent');
  if (mc) mc.style.background = gradients[name] || gradients.home;

  if (name === 'home')      loadSongs();
  if (name === 'stats')     loadStats();
  if (name === 'playlists') loadPlaylists();
  if (name === 'admin')     loadAdminSongs();
}

// ─── AUTH ─────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('loginForm').style.display    = tab === 'login'    ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
  const msg = document.getElementById('authMsg');
  if (msg) { msg.textContent = ''; msg.className = ''; }
}

async function register() {
  const username = document.getElementById('regUsername').value;
  const email    = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  const role     = document.getElementById('regRole').value;
  const res  = await fetch(`${API}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, email, password, role })
  });
  const data = await res.json();
  const msg  = document.getElementById('authMsg');
  if (res.ok) {
    msg.textContent = '✅ Registered! Please login.';
    msg.style.color = '#1db954';
  } else {
    msg.textContent = '❌ ' + data.error;
    msg.style.color = '#ff6b6b';
  }
}

async function login() {
  const email    = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  const res  = await fetch(`${API}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if (res.ok) {
    token = data.token;
    role  = data.role;
    localStorage.setItem('token', token);
    localStorage.setItem('role',  role);
    document.getElementById('authPage').classList.remove('active');
    document.getElementById('appLayout').style.display = 'grid';
    if (role === 'admin') document.getElementById('navAdmin').style.display = 'flex';
    showPage('home');
  } else {
    const msg = document.getElementById('authMsg');
    msg.textContent = '❌ ' + data.error;
    msg.style.color = '#ff6b6b';
  }
}

function logout() {
  localStorage.clear();
  token = ''; role = '';
  document.getElementById('appLayout').style.display = 'none';
  document.getElementById('authPage').classList.add('active');
  const pb = document.getElementById('playerBar');
  const cp = document.getElementById('commentsPanel');
  if (pb) pb.classList.remove('visible');
  if (cp) cp.classList.remove('open');
}

// ─── SONGS ────────────────────────────────────────────
async function loadSongs() {
  const search = document.getElementById('searchInput')?.value || '';
  const genre  = document.getElementById('genreFilter')?.value || '';
  let url = `${API}/api/songs?`;
  if (search) url += `search=${encodeURIComponent(search)}&`;
  if (genre)  url += `genre=${encodeURIComponent(genre)}`;
  const res   = await fetch(url);
  const songs = await res.json();
  const grid  = document.getElementById('songsGrid');
  grid.innerHTML = songs.length ? '' :
    `<div class="empty"><i class="fas fa-music"></i><br>No media found.</div>`;
  songs.forEach(song => {
    const filled   = Math.round(song.stats.avgRating);
    const stars    = '★'.repeat(filled) + '☆'.repeat(5 - filled);
    const tagClass = genreClass(song.genre.name);
    const card     = document.createElement('div');
    card.className = 'song-card';
    card.innerHTML = `
      <div class="song-thumb">
        <i class="fas fa-music"></i>
        <div class="play-btn"><i class="fas fa-play"></i></div>
      </div>
      <h4>${song.title}</h4>
      <p class="artist">${song.artist}</p>
      <span class="genre-tag ${tagClass}">${song.genre.name}</span>
      <div class="song-meta">
        <span>▶ ${song.stats.totalPlays}</span>
        <span class="stars">${stars} ${song.stats.avgRating}</span>
      </div>
    `;
    card.onclick = () => playSong(song);
    grid.appendChild(card);
  });
}

function filterGenre(genre) {
  const filter = document.getElementById('genreFilter');
  if (filter) filter.value = genre;
  showPage('home');
  loadSongs();
}

async function playSong(song) {
  currentSongId        = song._id;
  window.currentSongId = song._id;

  // Reset rating
  selectedRating       = 0;
  window.selectedRating = 0;

  const playerBar = document.getElementById('playerBar');
  if (playerBar) playerBar.classList.add('visible');

  const titleEl  = document.getElementById('playerTitle');
  const artistEl = document.getElementById('playerArtist');
  if (titleEl)  titleEl.textContent  = song.title;
  if (artistEl) artistEl.textContent = song.artist;

  const ytEl = document.getElementById('youtubePlayer');
  if (ytEl) ytEl.innerHTML =
    `<iframe width="320" height="180"
     src="https://www.youtube.com/embed/${song.youtubeId}?autoplay=1"
     frameborder="0" allow="autoplay; encrypted-media" allowfullscreen
     style="border-radius:4px"></iframe>`;

  // Load existing rating for this user
  try {
    const res  = await fetch(`/api/ratings/${song._id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    selectedRating        = data.rating || 0;
    window.selectedRating = selectedRating;
  } catch(e) {
    selectedRating        = 0;
    window.selectedRating = 0;
  }

  renderStars(0);
  const msg = document.getElementById('ratingMsg');
  if (msg) msg.textContent = selectedRating ? `You already rated this ${selectedRating} ⭐` : 'Click a star to rate';

  loadComments(song._id);

  fetch(`/api/songs/${song._id}/play`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
}

// ─── RATINGS ──────────────────────────────────────────
function renderStars(hovered) {
  const container = document.getElementById('ratingStars');
  if (!container) return;
  container.innerHTML = '';

  for (let i = 1; i <= 5; i++) {
    const star = document.createElement('span');
    star.textContent = '★';
    star.style.fontSize    = '1.4rem';
    star.style.cursor      = 'pointer';
    star.style.marginRight = '2px';
    star.style.color       = i <= (hovered || window.selectedRating) ? '#f5c518' : '#555';
    star.style.transition  = 'color 0.1s';
    star.dataset.val       = i;

    star.addEventListener('mouseover', function() {
      renderStars(parseInt(this.dataset.val));
    });

    star.addEventListener('mouseout', function() {
      renderStars(0);
    });

    star.addEventListener('click', function(e) {
      e.stopPropagation();
      const val             = parseInt(this.dataset.val);
      selectedRating        = val;
      window.selectedRating = val;
      renderStars(0);
      const msg = document.getElementById('ratingMsg');
      if (msg) msg.textContent = `${val} star${val > 1 ? 's' : ''} selected — click Rate`;
    });

    container.appendChild(star);
  }
}

async function submitRating() {
  const rating = window.selectedRating || selectedRating;

  const msg = document.getElementById('ratingMsg');

  if (!currentSongId) {
    if (msg) msg.textContent = '⚠️ Click a song first!';
    return;
  }
  if (!rating || rating === 0) {
    if (msg) msg.textContent = '⚠️ Click a star first!';
    return;
  }

  const res  = await fetch(`/api/ratings/${currentSongId}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ rating })
  });
  const data = await res.json();

  if (res.ok) {
    if (msg) msg.textContent = `✅ Rated! New avg: ${data.avgRating?.toFixed(1)} ⭐`;
    selectedRating        = 0;
    window.selectedRating = 0;
    loadSongs();
  } else {
    if (msg) msg.textContent = '❌ ' + data.error;
  }
}

// ─── COMMENTS ─────────────────────────────────────────
async function loadComments(songId) {
  const res      = await fetch(`${API}/api/comments/${songId}`);
  const comments = await res.json();
  const list     = document.getElementById('commentsList');
  if (!list) return;
  list.innerHTML = comments.length
    ? comments.map(c =>
        `<div class="comment-item">
          <span>${c.userId?.username || 'User'}:</span> ${c.commentText}
        </div>`
      ).join('')
    : '<p style="color:#727272;font-size:0.82rem;padding:0.5rem 0">No comments yet.</p>';
}

async function submitComment() {
  const input = document.getElementById('commentInput');
  const text  = input?.value.trim();
  if (!text || !currentSongId) return;
  await fetch(`${API}/api/comments/${currentSongId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ commentText: text })
  });
  input.value = '';
  loadComments(currentSongId);
  if (document.getElementById('commentsPanel')?.classList.contains('open')) {
    loadCommentsPanel(currentSongId);
  }
}

function toggleComments() {
  const panel = document.getElementById('commentsPanel');
  if (!panel) return;
  panel.classList.toggle('open');
  if (panel.classList.contains('open') && currentSongId) {
    loadCommentsPanel(currentSongId);
  }
}

async function loadCommentsPanel(songId) {
  const res      = await fetch(`${API}/api/comments/${songId}`);
  const comments = await res.json();
  const list     = document.getElementById('commentsListPanel');
  if (!list) return;
  list.innerHTML = comments.length
    ? comments.map(c =>
        `<div class="comment-item">
          <div class="comment-avatar">${(c.userId?.username || 'U')[0].toUpperCase()}</div>
          <div>
            <div class="comment-user">${c.userId?.username || 'User'}</div>
            <div class="comment-text">${c.commentText}</div>
          </div>
        </div>`
      ).join('')
    : '<p style="color:#727272;font-size:0.85rem;padding:0.5rem 0">No comments yet.</p>';
}

// ─── PLAYLISTS ────────────────────────────────────────
async function loadPlaylists() {
  const res       = await fetch(`${API}/api/playlists`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const playlists = await res.json();
  const grid      = document.getElementById('playlistsGrid');
  grid.innerHTML  = playlists.length ? '' :
    `<div class="empty"><i class="fas fa-list"></i><br>No playlists yet.</div>`;
  playlists.forEach(pl => {
    const card = document.createElement('div');
    card.className = 'playlist-card';
    card.innerHTML = `
      <div class="playlist-icon"><i class="fas fa-list-music"></i></div>
      <h4>${pl.playlistName}</h4>
      <p class="count">${pl.songs.length} tracks</p>
      <ul>
        ${pl.songs.slice(0, 4).map(s => `<li>• ${s.title} — ${s.artist}</li>`).join('')}
        ${pl.songs.length > 4 ? `<li style="color:#1db954">+${pl.songs.length - 4} more</li>` : ''}
      </ul>
      <button class="btn-del-playlist" onclick="deletePlaylist('${pl._id}')">
        <i class="fas fa-trash"></i> Delete
      </button>
    `;
    grid.appendChild(card);
  });
}

async function createPlaylist() {
  const name = document.getElementById('newPlaylistName').value.trim();
  if (!name) return;
  await fetch(`${API}/api/playlists`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ playlistName: name })
  });
  document.getElementById('newPlaylistName').value = '';
  loadPlaylists();
}

async function deletePlaylist(id) {
  if (!confirm('Delete this playlist?')) return;
  await fetch(`${API}/api/playlists/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  loadPlaylists();
}

// ─── STATS ────────────────────────────────────────────
async function loadStats() {
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const [topPlayed, topRated, genreRatings, songsPerMonth] = await Promise.all([
    fetch(`${API}/api/stats/top-played`).then(r => r.json()),
    fetch(`${API}/api/stats/top-rated`).then(r => r.json()),
    fetch(`${API}/api/stats/genre-ratings`).then(r => r.json()),
    fetch(`${API}/api/stats/songs-per-month`).then(r => r.json())
  ]);

  document.getElementById('topPlayed').innerHTML = topPlayed.length
    ? topPlayed.map(s => `<li>${s.title} <b style="color:#1db954">${s.stats.totalPlays} plays</b></li>`).join('')
    : '<li style="color:#727272">No data yet — play some songs!</li>';

  document.getElementById('topRated').innerHTML = topRated.length
    ? topRated.map(s => `<li>${s.title} <b style="color:#f5c518">${s.stats.avgRating}★</b></li>`).join('')
    : '<li style="color:#727272">No ratings yet!</li>';

  document.getElementById('genreRatings').innerHTML = genreRatings.length
    ? genreRatings.map(g => `<li>${g._id} <b style="color:#1db954">${g.avgRating?.toFixed(1)}★ (${g.totalSongs} songs)</b></li>`).join('')
    : '<li style="color:#727272">No data yet</li>';

  document.getElementById('songsPerMonth').innerHTML = songsPerMonth.length
    ? songsPerMonth.map(m => `<li>${months[m._id - 1]} <b style="color:#1db954">${m.count} added</b></li>`).join('')
    : '<li style="color:#727272">No data yet</li>';
}

// ─── ADMIN — ADD ──────────────────────────────────────
async function saveSong() {
  const song = {
    title:     document.getElementById('songTitle').value.trim(),
    artist:    document.getElementById('songArtist').value.trim(),
    youtubeId: document.getElementById('songYoutubeId').value.trim(),
    album: {
      name:        document.getElementById('songAlbum').value.trim(),
      releaseYear: parseInt(document.getElementById('songYear').value)
    },
    genre: { name: document.getElementById('songGenre').value }
  };
  if (!song.title || !song.artist || !song.youtubeId) {
    document.getElementById('adminMsg').textContent = '⚠️ Title, Artist and YouTube ID are required!';
    return;
  }
  const res  = await fetch(`${API}/api/songs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(song)
  });
  const data = await res.json();
  if (res.ok) {
    document.getElementById('adminMsg').textContent = '✅ Media added!';
    ['songTitle','songArtist','songYoutubeId','songAlbum','songYear'].forEach(id => {
      document.getElementById(id).value = '';
    });
    setTimeout(() => { document.getElementById('adminMsg').textContent = ''; }, 2000);
    loadAdminSongs();
  } else {
    document.getElementById('adminMsg').textContent = '❌ ' + data.error;
  }
}

// ─── ADMIN — LOAD ─────────────────────────────────────
async function loadAdminSongs() {
  const res   = await fetch(`${API}/api/songs`);
  const songs = await res.json();
  const grid  = document.getElementById('adminSongsList');
  grid.innerHTML = '';
  songs.forEach(song => {
    const tagClass = genreClass(song.genre.name);
    const row      = document.createElement('div');
    row.className  = 'admin-row';
    row.innerHTML  = `
      <div class="admin-row-icon"><i class="fas fa-music"></i></div>
      <div class="admin-row-info">
        <h4>${song.title}</h4>
        <p>
          <span><i class="fas fa-user"></i> ${song.artist}</span>
          <span class="genre-badge ${tagClass}">${song.genre.name}</span>
          <span><i class="fab fa-youtube" style="color:#ff0000"></i> ${song.youtubeId}</span>
          <span>▶ ${song.stats.totalPlays} &nbsp; ⭐ ${song.stats.avgRating}</span>
        </p>
      </div>
      <div class="admin-row-actions">
        <button class="btn-icon-green" onclick="openEditModal(this)"
          data-song='${JSON.stringify(song).replace(/'/g, "&#39;")}' title="Edit">
          <i class="fas fa-pen"></i>
        </button>
        <button class="btn-icon-red" onclick="deleteSong('${song._id}')" title="Delete">
          <i class="fas fa-trash"></i>
        </button>
      </div>
    `;
    grid.appendChild(row);
  });
}

async function deleteSong(id) {
  if (!confirm('Delete this media?')) return;
  await fetch(`${API}/api/songs/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  loadAdminSongs();
}

// ─── ADMIN — EDIT MODAL ───────────────────────────────
function openEditModal(btn) {
  const song    = JSON.parse(btn.getAttribute('data-song'));
  editingSongId = song._id;
  document.getElementById('editTitle').value     = song.title;
  document.getElementById('editArtist').value    = song.artist;
  document.getElementById('editYoutubeId').value = song.youtubeId;
  document.getElementById('editAlbum').value     = song.album?.name || '';
  document.getElementById('editYear').value      = song.album?.releaseYear || '';
  document.getElementById('editGenre').value     = song.genre?.name || 'Pop';
  document.getElementById('editMsg').textContent = '';
  document.getElementById('editModal').classList.add('open');
}

function closeModal() {
  document.getElementById('editModal').classList.remove('open');
  editingSongId = null;
}

async function updateSong() {
  const updated = {
    title:     document.getElementById('editTitle').value.trim(),
    artist:    document.getElementById('editArtist').value.trim(),
    youtubeId: document.getElementById('editYoutubeId').value.trim(),
    album: {
      name:        document.getElementById('editAlbum').value.trim(),
      releaseYear: parseInt(document.getElementById('editYear').value)
    },
    genre: { name: document.getElementById('editGenre').value }
  };
  const res  = await fetch(`${API}/api/songs/${editingSongId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(updated)
  });
  const data = await res.json();
  if (res.ok) {
    document.getElementById('editMsg').textContent = '✅ Updated!';
    setTimeout(() => { closeModal(); loadAdminSongs(); }, 1000);
  } else {
    document.getElementById('editMsg').textContent = '❌ ' + data.error;
  }
}

// ─── INIT ─────────────────────────────────────────────
window.onload = () => {
  const h  = new Date().getHours();
  const g  = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  const el = document.getElementById('greetingText');
  if (el) el.textContent = g;

  if (token) {
    document.getElementById('appLayout').style.display = 'grid';
    document.getElementById('authPage').classList.remove('active');
    if (role === 'admin') document.getElementById('navAdmin').style.display = 'flex';
    showPage('home');
  }
};