const mongoose = require('mongoose');

const songSchema = new mongoose.Schema({
  title:  { type: String, required: true, trim: true },
  artist: { type: String, required: true, trim: true },
  youtubeId: { type: String, required: true },

  album: {
    name:        { type: String, default: 'Unknown Album' },
    releaseYear: { type: Number }
  },

  genre: {
    name: { type: String, default: 'Unknown Genre' }
  },

  stats: {
    totalPlays:   { type: Number, default: 0 },
    avgRating:    { type: Number, default: 0 },
    totalRatings: { type: Number, default: 0 }
  },

  addedOn: { type: Date, default: Date.now }
});

// Indexes for fast search
songSchema.index({ title: 'text', artist: 'text' });
songSchema.index({ 'genre.name': 1 });
songSchema.index({ youtubeId: 1 });

module.exports = mongoose.model('Song', songSchema);