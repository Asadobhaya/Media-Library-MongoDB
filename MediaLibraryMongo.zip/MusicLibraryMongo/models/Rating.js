const mongoose = require('mongoose');

const ratingSchema = new mongoose.Schema({
  songId:  { type: mongoose.Schema.Types.ObjectId, ref: 'Song', required: true },
  userId:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rating:  { type: Number, required: true, min: 1, max: 5 },
  ratedOn: { type: Date, default: Date.now }
});

// One rating per user per song
ratingSchema.index({ songId: 1, userId: 1 }, { unique: true });

module.exports = mongoose.model('Rating', ratingSchema);