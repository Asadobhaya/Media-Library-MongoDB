const mongoose = require('mongoose');

const playHistorySchema = new mongoose.Schema({
  songId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Song', required: true },
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  playedOn: { type: Date, default: Date.now }
});

playHistorySchema.index({ userId: 1, playedOn: -1 });
playHistorySchema.index({ songId: 1 });

module.exports = mongoose.model('PlayHistory', playHistorySchema);