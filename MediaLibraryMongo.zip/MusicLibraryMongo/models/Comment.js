const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  songId:      { type: mongoose.Schema.Types.ObjectId, ref: 'Song', required: true },
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  commentText: { type: String, required: true, trim: true },
  commentDate: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Comment', commentSchema);