/******************************************************************
 MediaLib MongoDB Query Reference
 All MongoDB Queries Used in Project
******************************************************************/


// Create Song
Song.create({
    title: req.body.title,
    artist: req.body.artist,
    youtubeId: req.body.youtubeId,
    album: {
        name: req.body.album.name,
        releaseYear: req.body.album.releaseYear
    },
    genre: {
        name: req.body.genre.name
    },
    stats: {
        totalPlays: 0,
        avgRating: 0,
        totalRatings: 0
    }
});

// Create User
User.create({
    username,
    email,
    passwordHash,
    role
});

// Create Playlist
Playlist.create({
    userId: req.user.userId,
    playlistName: req.body.playlistName,
    songs: []
});

// Create Comment
Comment.create({
    songId: req.params.songId,
    userId: req.user.userId,
    commentText: req.body.commentText,
    commentDate: Date.now()
});

// Add Song To Playlist
Playlist.findByIdAndUpdate(
    req.params.id,
    {
        $addToSet: {
            songs: req.body.songId
        }
    },
    {
        new: true
    }
);

// Record Play History
Song.findByIdAndUpdate(
    req.params.id,
    {
        $inc: {
            "stats.totalPlays": 1
        }
    }
);

PlayHistory.create({
    songId: req.params.id,
    userId: req.user.userId,
    playedOn: new Date()
});


/* ==========================================================
   READ QUERIES
========================================================== */

// Search Songs
Song.find({
    $text: {
        $search: search
    }
});

// Filter By Genre
Song.find({
    "genre.name": genre
});

// Get Song By ID
Song.findById(req.params.id);

// Get User Playlists
Playlist.find({
    userId: req.user.userId
})
.populate(
    "songs",
    "title artist youtubeId"
);

// Get Comments
Comment.find({
    songId: req.params.songId
})
.populate(
    "userId",
    "username"
)
.sort({
    commentDate: -1
});

// Check Existing Rating
Rating.findOne({
    songId,
    userId
});

// Get User Rating
Rating.findOne({
    songId: req.params.songId,
    userId: req.user.userId
});


/* ==========================================================
   UPDATE QUERIES
========================================================== */

// Update Song
Song.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
        new: true
    }
);

// Increment Play Count
Song.findByIdAndUpdate(
    req.params.id,
    {
        $inc: {
            "stats.totalPlays": 1
        }
    }
);

// Update Rating Statistics
Song.findByIdAndUpdate(
    songId,
    {
        $set: {
            "stats.totalRatings": newTotal,
            "stats.avgRating": newAvg
        }
    },
    {
        session
    }
);


/* ==========================================================
   DELETE QUERIES
========================================================== */

// Delete Song
Song.findByIdAndDelete(req.params.id);

// Delete Playlist
Playlist.findByIdAndDelete(req.params.id);

// Delete Comment
Comment.findByIdAndDelete(req.params.id);


/* ==========================================================
   AGGREGATION QUERIES
========================================================== */

// Average Rating Per Genre
Song.aggregate([
{
    $group: {
        _id: "$genre.name",
        avgRating: {
            $avg: "$stats.avgRating"
        },
        totalSongs: {
            $sum: 1
        }
    }
},
{
    $sort: {
        avgRating: -1
    }
}
]);

// Songs Added Per Month
Song.aggregate([
{
    $group: {
        _id: {
            $month: "$addedOn"
        },
        count: {
            $sum: 1
        }
    }
},
{
    $sort: {
        _id: 1
    }
}
]);

// Top Rated Songs
Song.aggregate([
{
    $match: {
        "stats.totalRatings": {
            $gt: 0
        }
    }
},
{
    $sort: {
        "stats.avgRating": -1
    }
},
{
    $limit: 5
},
{
    $project: {
        title: 1,
        artist: 1,
        stats: 1
    }
}
]);


/* ==========================================================
   VIEWS
========================================================== */

// Top Rated Songs View
db.createCollection(
    "topRatedSongsView",
    {
        viewOn: "songs",
        pipeline: [
            {
                $match: {
                    "stats.totalRatings": {
                        $gt: 0
                    }
                }
            },
            {
                $sort: {
                    "stats.avgRating": -1
                }
            },
            {
                $limit: 10
            }
        ]
    }
);

// Trending Songs View
db.createCollection(
    "trendingSongsView",
    {
        viewOn: "songs",
        pipeline: [
            {
                $sort: {
                    "stats.totalPlays": -1
                }
            },
            {
                $limit: 10
            }
        ]
    }
);


/* ==========================================================
   INDEXES
========================================================== */

// Text Index
songSchema.index({
    title: "text",
    artist: "text"
});

// Unique Rating Index
ratingSchema.index(
{
    songId: 1,
    userId: 1
},
{
    unique: true
});

// Total Plays Index
db.collection("songs").createIndex({
    "stats.totalPlays": -1
});

// Average Rating Index
db.collection("songs").createIndex({
    "stats.avgRating": -1
});

// Genre Index
db.collection("songs").createIndex({
    "genre.name": 1
});

// Play History Index
playHistorySchema.index({
    userId: 1,
    playedOn: -1
});

// Song Analytics Index
playHistorySchema.index({
    songId: 1
});


/* ==========================================================
   TRANSACTIONS
========================================================== */

// Start Transaction
const session = await mongoose.startSession();
session.startTransaction();

// Read In Transaction
Rating.findOne({
    songId,
    userId
}).session(session);

// Insert In Transaction
Rating.create(
[
{
    songId,
    userId,
    rating
}
],
{
    session
});

// Update In Transaction
Song.findByIdAndUpdate(
    songId,
    {
        $set: {
            "stats.totalRatings": newTotal,
            "stats.avgRating": newAvg
        }
    },
    {
        session
    }
);

// Commit Transaction
session.commitTransaction();

// Rollback Transaction
session.abortTransaction();

// End Session
session.endSession();


/* ==========================================================
   VALIDATIONS
========================================================== */

// User Validation
username: {
    type: String,
    required: true,
    trim: true
}

email: {
    type: String,
    required: true,
    unique: true
}

role: {
    type: String,
    enum: ["admin", "user"]
}

// Rating Validation
rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5
}