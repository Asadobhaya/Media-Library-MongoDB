const express = require('express');
const router = express.Router();
const Playlist = require('../models/Playlist');
const { protect } = require('../middleware/auth');

// GET MY PLAYLISTS
router.get('/', protect, async (req, res) => {
  try {
    const playlists = await Playlist.find({ userId: req.user.userId })
      .populate('songs', 'title artist youtubeId');
    res.json(playlists);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE PLAYLIST
router.post('/', protect, async (req, res) => {
  try {
    const playlist = await Playlist.create({
      userId: req.user.userId,
      playlistName: req.body.playlistName
    });
    res.status(201).json(playlist);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ADD SONG TO PLAYLIST
router.post('/:id/songs', protect, async (req, res) => {
  try {
    const playlist = await Playlist.findByIdAndUpdate(
      req.params.id,
      { $addToSet: { songs: req.body.songId } },
      { new: true }
    );
    res.json(playlist);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE PLAYLIST
router.delete('/:id', protect, async (req, res) => {
  try {
    await Playlist.findByIdAndDelete(req.params.id);
    res.json({ message: 'Playlist deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;