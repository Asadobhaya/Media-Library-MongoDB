const express = require('express');
const router = express.Router();
const Song = require('../models/Song');
const { protect, adminOnly } = require('../middleware/auth');

// GET ALL SONGS
router.get('/', async (req, res) => {
  try {
    const { search, genre } = req.query;
    let query = {};
    if (search) query.$text = { $search: search };
    if (genre)  query['genre.name'] = genre;
    const songs = await Song.find(query).sort({ addedOn: -1 });
    res.json(songs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET SINGLE SONG
router.get('/:id', async (req, res) => {
  try {
    const song = await Song.findById(req.params.id);
    if (!song) return res.status(404).json({ error: 'Song not found' });
    res.json(song);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ADD SONG (admin only)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const song = await Song.create(req.body);
    res.status(201).json(song);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// UPDATE SONG (admin only)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const song = await Song.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!song) return res.status(404).json({ error: 'Song not found' });
    res.json(song);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE SONG (admin only)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await Song.findByIdAndDelete(req.params.id);
    res.json({ message: 'Song deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// RECORD PLAY
router.post('/:id/play', protect, async (req, res) => {
  try {
    await Song.findByIdAndUpdate(req.params.id, {
      $inc: { 'stats.totalPlays': 1 }
    });
    const PlayHistory = require('../models/PlayHistory');
    await PlayHistory.create({ songId: req.params.id, userId: req.user.userId });
    res.json({ message: 'Play recorded' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;