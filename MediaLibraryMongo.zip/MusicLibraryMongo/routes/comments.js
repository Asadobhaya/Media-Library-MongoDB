const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');
const { protect } = require('../middleware/auth');

// GET COMMENTS FOR A SONG
router.get('/:songId', async (req, res) => {
  try {
    const comments = await Comment.find({ songId: req.params.songId })
      .populate('userId', 'username')
      .sort({ commentDate: -1 });
    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ADD COMMENT
router.post('/:songId', protect, async (req, res) => {
  try {
    const comment = await Comment.create({
      songId: req.params.songId,
      userId: req.user.userId,
      commentText: req.body.commentText
    });
    res.status(201).json(comment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE COMMENT
router.delete('/:id', protect, async (req, res) => {
  try {
    await Comment.findByIdAndDelete(req.params.id);
    res.json({ message: 'Comment deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;