const express = require('express');
const router = express.Router();
const Song = require('../models/Song');
const PlayHistory = require('../models/PlayHistory');

// TOP 5 MOST PLAYED SONGS
router.get('/top-played', async (req, res) => {
  try {
    const songs = await Song.find()
      .sort({ 'stats.totalPlays': -1 })
      .limit(5)
      .select('title artist stats.totalPlays');
    res.json(songs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// AVERAGE RATING PER GENRE
router.get('/genre-ratings', async (req, res) => {
  try {
    const result = await Song.aggregate([
      { $group: {
          _id: '$genre.name',
          avgRating: { $avg: '$stats.avgRating' },
          totalSongs: { $sum: 1 }
      }},
      { $sort: { avgRating: -1 } }
    ]);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// SONGS ADDED PER MONTH
router.get('/songs-per-month', async (req, res) => {
  try {
    const result = await Song.aggregate([
      { $group: {
          _id: { $month: '$addedOn' },
          count: { $sum: 1 }
      }},
      { $sort: { '_id': 1 } }
    ]);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// TOP RATED SONGS
router.get('/top-rated', async (req, res) => {
  try {
    const songs = await Song.find({ 'stats.totalRatings': { $gt: 0 } })
      .sort({ 'stats.avgRating': -1 })
      .limit(5)
      .select('title artist stats');
    res.json(songs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;