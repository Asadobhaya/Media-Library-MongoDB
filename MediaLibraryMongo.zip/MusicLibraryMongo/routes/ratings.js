const express = require('express');
const router = express.Router();
const Rating = require('../models/Rating');
const Song = require('../models/Song');
const { protect } = require('../middleware/auth');

// RATE A SONG
router.post('/:songId', protect, async (req, res) => {
  try {
    const { rating } = req.body;
    const { songId } = req.params;
    const userId = req.user.userId;

    // Check if already rated
    const existing = await Rating.findOne({ songId, userId });
    if (existing) {
      return res.status(400).json({ error: 'You already rated this song' });
    }

    // Insert rating
    await Rating.create({ songId, userId, rating });

    // Update song stats atomically
    const song = await Song.findById(songId);
    const newTotal = song.stats.totalRatings + 1;
    const newAvg   = ((song.stats.avgRating * song.stats.totalRatings) + rating) / newTotal;

    await Song.findByIdAndUpdate(songId, {
      $set: {
        'stats.totalRatings': newTotal,
        'stats.avgRating':    Math.round(newAvg * 10) / 10
      }
    });

    res.json({ message: 'Rating submitted', avgRating: Math.round(newAvg * 10) / 10 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET RATING FOR A SONG BY USER
router.get('/:songId', protect, async (req, res) => {
  try {
    const rating = await Rating.findOne({
      songId: req.params.songId,
      userId: req.user.userId
    });
    res.json({ rating: rating ? rating.rating : 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;